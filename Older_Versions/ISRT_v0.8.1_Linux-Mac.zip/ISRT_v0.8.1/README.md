# ISRT-Insurgency-Sandstorm-RCON-Query-Tool

*Discontinued on GitHUB - please go to http://www.isrt.info*

For issue reporting or bug tracking, use this ticketing system: https://www.isrt.info/?page_id=661
